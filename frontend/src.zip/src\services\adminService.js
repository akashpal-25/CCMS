import { complaintService } from './complaintService';
import { COMPLAINT_STATUS } from '../utils/constants';

export const adminService = {
  getAdminComplaints: async (filters = {}) => {
    const complaints = await complaintService.getDepartmentComplaints();
    let data = [...complaints];

    if (filters.status && filters.status !== 'ALL') {
      data = data.filter((c) => c.status === filters.status);
    }
    if (filters.search) {
      const q = filters.search.toLowerCase();
      data = data.filter(
        (c) =>
          c.title.toLowerCase().includes(q) ||
          c.complaint_number.toLowerCase().includes(q)
      );
    }
    return data;
  },

  getAdminStats: async () => {
    const complaints = await adminService.getAdminComplaints();
    return {
      total: complaints.length,
      underReview: complaints.filter((c) => c.status === COMPLAINT_STATUS.UNDER_REVIEW).length,
      pendingConfirmation: complaints.filter((c) => c.status === COMPLAINT_STATUS.PENDING_STUDENT_CONFIRMATION).length,
      escalated: complaints.filter((c) => c.status === COMPLAINT_STATUS.ESCALATED).length,
      resolved: complaints.filter((c) => c.status === COMPLAINT_STATUS.RESOLVED).length,
      notSolved: complaints.filter((c) => c.status === COMPLAINT_STATUS.NOT_SOLVED).length,
    };
  },

  // NOTE: Backend abhi "saare users ki list" wala API nahi deta (Phase 7 me nahi bana tha).
  // Jab tak wo endpoint banayenge, ye function khali list dega — crash nahi karega.
  getAllUsers: async () => {
    console.warn('getAllUsers: backend endpoint abhi tak nahi bana.');
    return [];
  },

  toggleUserStatus: async () => {
    console.warn('toggleUserStatus: backend endpoint abhi tak nahi bana.');
    return false;
  },
};