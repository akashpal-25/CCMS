import { create } from 'zustand';
import { complaintService } from '../services/complaintService';
import { studentService } from '../services/studentService';

export const useStudentStore = create((set, get) => ({
  complaints: [],
  stats: null,
  activeComplaint: null,
  isLoading: false,
  error: null,

  fetchStudentComplaints: async (studentId) => {
    set({ isLoading: true, error: null });
    try {
      const data = await complaintService.getComplaints({ studentId });
      const stats = await studentService.getStudentStats(studentId);
      set({ complaints: data, stats, isLoading: false });
    } catch (err) {
      set({ error: err.message, isLoading: false });
    }
  },

  fetchComplaintById: async (id) => {
    set({ isLoading: true, error: null });
    try {
      const data = await complaintService.getComplaintById(id);
      set({ activeComplaint: data, isLoading: false });
      return data;
    } catch (err) {
      set({ error: err.message, isLoading: false });
      throw err;
    }
  },

  submitNewComplaint: async (payload, student) => {
    set({ isLoading: true, error: null });
    try {
      const created = await complaintService.createComplaint(payload, student);
      set((state) => ({
        complaints: [created, ...state.complaints],
        isLoading: false
      }));
      return created;
    } catch (err) {
      set({ error: err.message, isLoading: false });
      throw err;
    }
  },

  submitFeedback: async (id, isSolved, note, studentName) => {
    try {
      const updated = await complaintService.resolveWithFeedback(id, isSolved, note, studentName);
      set((state) => ({
        activeComplaint: updated,
        complaints: state.complaints.map((c) => (c.id === id ? updated : c))
      }));
      return updated;
    } catch (err) {
      set({ error: err.message });
      throw err;
    }
  }
}));