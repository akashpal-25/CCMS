import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Send, ArrowLeft } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useStudentStore } from '../../store/studentStore';
import { DOMAINS, DOMAIN_CATEGORIES } from '../../utils/constants';
import { validateComplaintForm } from '../../utils/validators';
import Card from '../../components/ui/Card';
import Input from '../../components/common/Input';
import Button from '../../components/common/Button';
import AttachmentUploader from '../../components/complaints/AttachmentUploader';

const SubmitComplaint = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuthStore();
  const { submitNewComplaint, isLoading } = useStudentStore();

  const [domain, setDomain] = useState(location.state?.defaultDomain || DOMAINS.ACADEMIC);
  const [category, setCategory] = useState(DOMAIN_CATEGORIES[location.state?.defaultDomain || DOMAINS.ACADEMIC][0]);
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [attachments, setAttachments] = useState([]);
  const [errors, setErrors] = useState({});

  const handleDomainChange = (e) => {
    const nextDomain = e.target.value;
    setDomain(nextDomain);
    setCategory(DOMAIN_CATEGORIES[nextDomain][0]);
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const validation = validateComplaintForm({ domain, category, title, description });
    if (!validation.isValid) {
      setErrors(validation.errors);
      return;
    }

    try {
      const created = await submitNewComplaint(
        { domain, category, title, description, attachments },
        user
      );
      navigate(`/student/complaints/${created.id}`);
    } catch {
      // Handled by store
    }
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      <Button variant="outline" size="sm" icon={ArrowLeft} onClick={() => navigate(-1)} style={{ alignSelf: 'flex-start' }}>
        Back
      </Button>

      <Card style={{ padding: '2rem' }}>
        <div style={{ marginBottom: '1.5rem', borderBottom: '1px solid var(--color-border)', paddingBottom: '1rem' }}>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 700, color: 'var(--color-primary)' }}>Submit Formal Grievance</h2>
          <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>
            Fill out the details below. The CCMS auto-routing engine will dispatch this directly to the responsible authority.
          </p>
        </div>

        <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          {/* Domain Selection */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.375rem' }}>
            <label style={{ fontSize: '0.875rem', fontWeight: 500 }}>Grievance Domain *</label>
            <select
              value={domain}
              onChange={handleDomainChange}
              style={{
                padding: '0.625rem 0.875rem',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--color-border)',
                backgroundColor: 'var(--color-bg-surface)',
                outline: 'none',
                fontSize: '0.875rem'
              }}
            >
              {Object.values(DOMAINS).map((d) => (
                <option key={d} value={d}>{d}</option>
              ))}
            </select>
          </div>

          {/* Category Selection */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.375rem' }}>
            <label style={{ fontSize: '0.875rem', fontWeight: 500 }}>Specific Category *</label>
            <select
              value={category}
              onChange={(e) => setCategory(e.target.value)}
              style={{
                padding: '0.625rem 0.875rem',
                borderRadius: 'var(--radius-md)',
                border: '1px solid var(--color-border)',
                backgroundColor: 'var(--color-bg-surface)',
                outline: 'none',
                fontSize: '0.875rem'
              }}
            >
              {DOMAIN_CATEGORIES[domain].map((cat) => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Title */}
          <Input
            label="Brief Subject / Title"
            id="title"
            value={title}
            onChange={(e) => setTitle(e.target.value)}
            placeholder="e.g. Discrepancy in Continuous Assessment (CA-1) attendance marks"
            error={errors.title}
            required
          />

          {/* Description */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.375rem' }}>
            <label style={{ fontSize: '0.875rem', fontWeight: 500 }}>
              Detailed Description *
            </label>
            <textarea
              rows={5}
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              placeholder="State the dates, subject codes, faculty name or exact location of the issue..."
              style={{
                padding: '0.75rem',
                borderRadius: 'var(--radius-md)',
                border: `1px solid ${errors.description ? 'var(--status-not-solved-text)' : 'var(--color-border)'}`,
                outline: 'none',
                fontFamily: 'inherit',
                fontSize: '0.875rem'
              }}
            />
            {errors.description && (
              <span style={{ fontSize: '0.75rem', color: 'var(--status-not-solved-text)' }}>{errors.description}</span>
            )}
          </div>

          {/* Attachment Uploader */}
          <AttachmentUploader files={attachments} onFilesChange={setAttachments} />

          <div style={{ display: 'flex', justifyContent: 'flex-end', gap: '0.75rem', marginTop: '1rem' }}>
            <Button variant="secondary" onClick={() => navigate(-1)}>Cancel</Button>
            <Button type="submit" variant="primary" isLoading={isLoading} icon={Send}>
              Submit Complaint
            </Button>
          </div>
        </form>
      </Card>
    </div>
  );
};

export default SubmitComplaint;