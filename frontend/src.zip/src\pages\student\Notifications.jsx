import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Bell, CheckCheck } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useNotificationStore } from '../../store/notificationStore';
import Card from '../../components/ui/Card';
import Button from '../../components/common/Button';
import EmptyState from '../../components/common/EmptyState';
import { formatDate } from '../../utils/formatters';

const Notifications = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { notifications, fetchNotifications, markRead, markAllRead } = useNotificationStore();

  useEffect(() => {
    if (user?.id) {
      fetchNotifications(user.id);
    }
  }, [user]);

  const handleNotificationClick = async (n) => {
    await markRead(n.id);
    if (n.link) navigate(n.link);
  };

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
      
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <div>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Notifications</h2>
          <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Grievance alerts, resolution confirmations and comments.</p>
        </div>
        {notifications.length > 0 && (
          <Button variant="outline" size="sm" icon={CheckCheck} onClick={markAllRead}>
            Mark all read
          </Button>
        )}
      </div>

      {notifications.length === 0 ? (
        <EmptyState title="No notifications" description="You are all caught up on all complaint alerts." />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {notifications.map((n) => (
            <Card
              key={n.id}
              onClick={() => handleNotificationClick(n)}
              style={{
                cursor: 'pointer',
                padding: '1rem',
                backgroundColor: n.read ? 'var(--color-bg-surface)' : 'var(--color-primary-light)',
                borderLeft: n.read ? '1px solid var(--color-border)' : '4px solid var(--color-primary)'
              }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                <span style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--color-text-main)' }}>{n.title}</span>
                <span style={{ fontSize: '0.7rem', color: 'var(--color-text-light)' }}>{formatDate(n.createdAt)}</span>
              </div>
              <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', margin: 0 }}>{n.message}</p>
            </Card>
          ))}
        </div>
      )}

    </div>
  );
};

export default Notifications;