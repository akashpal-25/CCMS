import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle2, XCircle, FileText, Send } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { useStudentStore } from '../../store/studentStore';
import Card from '../../components/ui/Card';
import Button from '../../components/common/Button';
import StatusBadge from '../../components/ui/StatusBadge';
import SLATimer from '../../components/complaints/SLATimer';
import ComplaintTimeline from '../../components/complaints/ComplaintTimeline';
import Loader from '../../components/common/Loader';
import { formatDate } from '../../utils/formatters';

const StudentComplaintDetails = () => {
  const { complaintId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const { activeComplaint, fetchComplaintById, submitFeedback, isLoading } = useStudentStore();

  const [feedbackNote, setFeedbackNote] = useState('');
  const [showFeedbackModal, setShowFeedbackModal] = useState(false);

  useEffect(() => {
    if (complaintId) {
      fetchComplaintById(complaintId);
    }
  }, [complaintId]);

  if (isLoading || !activeComplaint) return <Loader message="Loading grievance record..." />;

  const handleResolveFeedback = async (isSolved) => {
    await submitFeedback(activeComplaint.id, isSolved, feedbackNote, user?.name);
    setShowFeedbackModal(false);
  };

  return (
    <div style={{ maxWidth: '1000px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      
      <Button variant="outline" size="sm" icon={ArrowLeft} onClick={() => navigate('/student/complaints')} style={{ alignSelf: 'flex-start' }}>
        Back to My Complaints
      </Button>

      {/* Header Info */}
      <Card style={{ padding: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <span style={{ fontSize: '1.125rem', fontFamily: 'monospace', fontWeight: 700, color: 'var(--color-primary)' }}>
              {activeComplaint.id}
            </span>
            <StatusBadge status={activeComplaint.status} />
          </div>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 700, marginTop: '0.35rem' }}>{activeComplaint.title}</h2>
          <span style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>
            Domain: {activeComplaint.domain} • Category: {activeComplaint.category} • Submitted: {formatDate(activeComplaint.createdAt)}
          </span>
        </div>
      </Card>

      {/* SLA Timer */}
      <SLATimer
        deadline={activeComplaint.slaDeadline}
        status={activeComplaint.status}
      />

      {/* Confirmation feedback loop for student */}
      {activeComplaint.status !== 'RESOLVED' && activeComplaint.status !== 'CLOSED' && (
        <Card style={{ backgroundColor: 'var(--color-primary-light)', borderColor: 'var(--color-accent)', padding: '1.25rem' }}>
          <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, color: 'var(--color-primary)', marginBottom: '0.35rem' }}>
            Student Resolution Confirmation
          </h4>
          <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-main)', marginBottom: '0.75rem' }}>
            Has your complaint been satisfactorily addressed by the administration?
          </p>
          <div style={{ display: 'flex', gap: '0.75rem' }}>
            <Button size="sm" variant="success" icon={CheckCircle2} onClick={() => handleResolveFeedback(true)}>
              YES — Problem Solved
            </Button>
            <Button size="sm" variant="danger" icon={XCircle} onClick={() => handleResolveFeedback(false)}>
              NO — Problem Not Solved (Escalate)
            </Button>
          </div>
        </Card>
      )}

      {/* Main Grid: Details + Timeline */}
      <div style={{ display: 'grid', gridTemplateColumns: '1.4fr 1fr', gap: '1.5rem' }}>
        
        {/* Left: Description & Attachments */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          <Card>
            <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, marginBottom: '0.75rem' }}>Grievance Statement</h4>
            <p style={{ fontSize: '0.875rem', lineHeight: 1.6, color: 'var(--color-text-main)', whiteSpace: 'pre-line' }}>
              {activeComplaint.description}
            </p>
          </Card>

          {activeComplaint.attachments?.length > 0 && (
            <Card>
              <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, marginBottom: '0.75rem' }}>Attached Documents</h4>
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.5rem' }}>
                {activeComplaint.attachments.map((att, idx) => (
                  <div key={idx} style={{ display: 'flex', alignItems: 'center', gap: '0.5rem', padding: '0.5rem', backgroundColor: 'var(--color-bg-muted)', borderRadius: 'var(--radius-md)' }}>
                    <FileText size={16} />
                    <span style={{ fontSize: '0.8125rem', fontWeight: 500 }}>{att.name}</span>
                  </div>
                ))}
              </div>
            </Card>
          )}

          {/* Official Comments */}
          <Card>
            <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, marginBottom: '0.75rem' }}>Official Remarks & Comments</h4>
            {activeComplaint.comments?.length === 0 ? (
              <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>No administrative remarks recorded yet.</p>
            ) : (
              <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
                {activeComplaint.comments.map((com) => (
                  <div key={com.id} style={{ padding: '0.75rem', backgroundColor: 'var(--color-bg-muted)', borderRadius: 'var(--radius-md)' }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', marginBottom: '0.25rem' }}>
                      <span style={{ fontSize: '0.8125rem', fontWeight: 600 }}>{com.author} ({com.role})</span>
                      <span style={{ fontSize: '0.7rem', color: 'var(--color-text-light)' }}>{formatDate(com.timestamp)}</span>
                    </div>
                    <p style={{ fontSize: '0.8125rem', margin: 0 }}>{com.message}</p>
                  </div>
                ))}
              </div>
            )}
          </Card>
        </div>

        {/* Right: Timeline Audit */}
        <div>
          <Card>
            <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, marginBottom: '1rem' }}>Lifecycle Audit Trail</h4>
            <ComplaintTimeline timeline={activeComplaint.timeline} />
          </Card>
        </div>

      </div>

    </div>
  );
};

export default StudentComplaintDetails;