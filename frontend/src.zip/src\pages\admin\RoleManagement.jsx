import React from 'react';
import Card from '../../components/ui/Card';
import Table from '../../components/ui/Table';

const RoleManagement = () => {
  // Pre-filled role matrix data removed; ready for dynamic API binding
  const roleMatrix = [];

  const headers = ['Role Identifier', 'Scope of Record Visibility', 'SLA Permissions', 'Routing Tier'];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Role-Based Access Control (RBAC) Matrix</h2>
        <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Configured security permissions for frontend simulation and FastAPI JWT scoping.</p>
      </div>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <Table headers={headers}>
          {roleMatrix.length === 0 ? (
            <tr>
              <td colSpan={headers.length} style={{ padding: '2rem', textAlign: 'center', color: 'var(--color-text-muted)', fontSize: '0.875rem' }}>
                No role definitions configured yet.
              </td>
            </tr>
          ) : (
            roleMatrix.map((r, idx) => (
              <tr key={idx} style={{ borderBottom: '1px solid var(--color-border)' }}>
                <td style={{ padding: '1rem', fontWeight: 600 }}>{r.role}</td>
                <td style={{ padding: '1rem', fontSize: '0.8125rem' }}>{r.scope}</td>
                <td style={{ padding: '1rem', fontSize: '0.8125rem' }}>{r.slaAction}</td>
                <td style={{ padding: '1rem', fontSize: '0.8125rem' }}>{r.routing}</td>
              </tr>
            ))
          )}
        </Table>
      </Card>
    </div>
  );
};

export default RoleManagement;