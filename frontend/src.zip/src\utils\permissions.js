import { ROLES, DOMAINS } from './constants';

export const isStudent = (role) => role === ROLES.STUDENT;

export const isAdmin = (role) => role && role !== ROLES.STUDENT;

export const isSuperAdmin = (role) => role === ROLES.SUPER_ADMIN;

export const isDirector = (role) => role === ROLES.DIRECTOR;

export const canViewComplaint = (user, complaint) => {
  if (!user || !complaint) return false;
  if (user.role === ROLES.SUPER_ADMIN || user.role === ROLES.DIRECTOR) return true;
  if (user.role === ROLES.STUDENT) return complaint.studentId === user.collegeId;

  // Department check for HOD and Class Teacher
  if (user.role === ROLES.HOD || user.role === ROLES.CLASS_TEACHER) {
    return complaint.department === user.department;
  }

  // Domain checks
  if (user.role === ROLES.EXAM_ADMIN) return complaint.domain === DOMAINS.EXAMINATION;
  if (user.role === ROLES.LIBRARY_ADMIN) return complaint.domain === DOMAINS.LIBRARY;
  if (user.role === ROLES.HR_FINANCE_ADMIN) return complaint.domain === DOMAINS.FINANCE;
  if (user.role === ROLES.WARDEN) return complaint.category.toLowerCase().includes('hostel');
  if (user.role === ROLES.TRANSPORT_SUPERVISOR) return complaint.category.toLowerCase().includes('bus') || complaint.category.toLowerCase().includes('transport');

  return complaint.assignedToRole === user.role;
};

export const canUpdateComplaint = (user, complaint) => {
  if (!user || !complaint) return false;
  if (user.role === ROLES.STUDENT) return false;
  if (user.role === ROLES.SUPER_ADMIN || user.role === ROLES.DIRECTOR) return true;
  return canViewComplaint(user, complaint);
};

export const determineInitialRouting = (domain, category) => {
  if (domain === DOMAINS.ACADEMIC) {
    if (category.includes('Faculty')) return ROLES.HOD;
    return ROLES.CLASS_TEACHER;
  }
  if (domain === DOMAINS.EXAMINATION) return ROLES.EXAM_ADMIN;
  if (domain === DOMAINS.LIBRARY) return ROLES.HOD;
  if (domain === DOMAINS.FINANCE) return ROLES.HOD;
  if (domain === DOMAINS.GENERAL) {
    if (category.toLowerCase().includes('hostel')) return ROLES.WARDEN;
    if (category.toLowerCase().includes('bus') || category.toLowerCase().includes('transport')) return ROLES.TRANSPORT_SUPERVISOR;
    return ROLES.HOD;
  }
  return ROLES.CLASS_TEACHER;
};