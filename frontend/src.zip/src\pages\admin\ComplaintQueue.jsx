import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuthStore } from '../../store/authStore';
import { adminService } from '../../services/adminService';
import { DOMAINS, COMPLAINT_STATUS } from '../../utils/constants';
import Card from '../../components/ui/Card';
import Table from '../../components/ui/Table';
import Input from '../../components/common/Input';
import Button from '../../components/common/Button';
import StatusBadge from '../../components/ui/StatusBadge';
import EmptyState from '../../components/common/EmptyState';
import { formatDate } from '../../utils/formatters';

const ComplaintQueue = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [complaints, setComplaints] = useState([]);
  const [search, setSearch] = useState('');
  const [domainFilter, setDomainFilter] = useState('ALL');
  const [statusFilter, setStatusFilter] = useState('ALL');
  const [loading, setLoading] = useState(true);

  const loadData = async () => {
    setLoading(true);
    const data = await adminService.getAdminComplaints(user, { search, domain: domainFilter, status: statusFilter });
    setComplaints(data);
    setLoading(false);
  };

  useEffect(() => {
    loadData();
  }, [user, domainFilter, statusFilter]);

  const headers = ['Complaint ID', 'Student', 'Department', 'Domain', 'Status', 'Date', 'Action'];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Institutional Complaint Queue</h2>
        <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Role-filtered queue of grievances assigned to your administrative unit.</p>
      </div>

      {/* Filter Bar */}
      <Card style={{ padding: '1rem', display: 'flex', gap: '1rem', flexWrap: 'wrap', alignItems: 'center' }}>
        <div style={{ flex: 1, minWidth: '240px' }}>
          <Input
            placeholder="Search by student, ID or title..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
          />
        </div>

        <Button variant="secondary" size="sm" onClick={loadData}>
          Search
        </Button>

        <select
          value={domainFilter}
          onChange={(e) => setDomainFilter(e.target.value)}
          style={{ padding: '0.55rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', fontSize: '0.8125rem' }}
        >
          <option value="ALL">All Domains</option>
          {Object.values(DOMAINS).map((d) => (
            <option key={d} value={d}>{d}</option>
          ))}
        </select>

        <select
          value={statusFilter}
          onChange={(e) => setStatusFilter(e.target.value)}
          style={{ padding: '0.55rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', fontSize: '0.8125rem' }}
        >
          <option value="ALL">All Statuses</option>
          {Object.values(COMPLAINT_STATUS).map((s) => (
            <option key={s} value={s}>{s}</option>
          ))}
        </select>
      </Card>

      {/* Table */}
      <Card style={{ padding: 0, overflow: 'hidden' }}>
        {complaints.length === 0 ? (
          <EmptyState title="No complaints match this queue filter" />
        ) : (
          <Table headers={headers}>
            {complaints.map((c) => (
              <tr key={c.id} style={{ borderBottom: '1px solid var(--color-border)' }}>
                <td style={{ padding: '1rem', fontFamily: 'monospace', fontWeight: 700, color: 'var(--color-primary)' }}>{c.id}</td>
                <td style={{ padding: '1rem' }}>
                  <div style={{ fontWeight: 600 }}>{c.studentName}</div>
                  <div style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>{c.studentId}</div>
                </td>
                <td style={{ padding: '1rem', fontSize: '0.8125rem' }}>{c.department}</td>
                <td style={{ padding: '1rem', fontSize: '0.8125rem' }}>{c.domain}</td>
                <td style={{ padding: '1rem' }}><StatusBadge status={c.status} /></td>
                <td style={{ padding: '1rem', fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>{formatDate(c.createdAt)}</td>
                <td style={{ padding: '1rem' }}>
                  <Button size="sm" variant="outline" onClick={() => navigate(`/admin/complaints/${c.id}`)}>
                    Review
                  </Button>
                </td>
              </tr>
            ))}
          </Table>
        )}
      </Card>
    </div>
  );
};

export default ComplaintQueue;