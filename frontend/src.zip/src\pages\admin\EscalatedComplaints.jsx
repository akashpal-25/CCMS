import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ShieldAlert } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { complaintService } from '../../services/complaintService';
import { COMPLAINT_STATUS } from '../../utils/constants';
import Card from '../../components/ui/Card';
import StatusBadge from '../../components/ui/StatusBadge';
import EmptyState from '../../components/common/EmptyState';
import { formatDate } from '../../utils/formatters';

const EscalatedComplaints = () => {
  const navigate = useNavigate();
  const { user } = useAuthStore();
  const [escalated, setEscalated] = useState([]);

  useEffect(() => {
    const load = async () => {
      const data = await complaintService.getComplaints({ status: COMPLAINT_STATUS.ESCALATED });
      setEscalated(data);
    };
    load();
  }, []);

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Apex Escalation Center</h2>
        <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>
          Grievances flagged due to 72-hour SLA breach or unsatisfied student confirmation.
        </p>
      </div>

      {escalated.length === 0 ? (
        <EmptyState title="Zero active escalations" description="All department grievances are proceeding within SLA tolerances." />
      ) : (
        <div style={{ display: 'flex', flexDirection: 'column', gap: '0.75rem' }}>
          {escalated.map((c) => (
            <Card
              key={c.id}
              onClick={() => navigate(`/admin/complaints/${c.id}`)}
              style={{ cursor: 'pointer', borderLeft: '4px solid var(--status-escalated-text)', padding: '1.25rem' }}
            >
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                <div>
                  <span style={{ fontFamily: 'monospace', fontWeight: 700, color: 'var(--color-primary)' }}>{c.id}</span>
                  <h4 style={{ fontSize: '1rem', fontWeight: 600, marginTop: '0.2rem' }}>{c.title}</h4>
                  <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)' }}>
                    Student: {c.studentName} • Dept: {c.department} • Escalated to: {c.assignedToRole}
                  </span>
                </div>
                <StatusBadge status={c.status} />
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default EscalatedComplaints;