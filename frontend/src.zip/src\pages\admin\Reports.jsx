import React, { useState } from 'react';
import Card from '../../components/ui/Card';

const Reports = () => {
  // Hardcoded percentages removed; ready for dynamic API statistics
  const [reportStats, setReportStats] = useState({
    slaComplianceRate: 0,
    avgResolutionHours: 0.0,
    escalationRate: 0
  });

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Institutional Redressal & SLA Reports</h2>
        <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>
          Performance audit of grievance turnaround time and SLA compliance across departments.
        </p>
      </div>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(280px, 1fr))', gap: '1.5rem' }}>
        <Card>
          <h4 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '1rem' }}>SLA Compliance Rate</h4>
          <div style={{ fontSize: '2.5rem', fontWeight: 800, color: 'var(--status-resolved-text)' }}>
            {reportStats.slaComplianceRate}%
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', marginTop: '0.5rem' }}>
            Resolved within the standard 72-hour window across all departments this semester.
          </p>
        </Card>

        <Card>
          <h4 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '1rem' }}>Average Resolution Turnaround</h4>
          <div style={{ fontSize: '2.5rem', fontWeight: 800, color: 'var(--color-primary)' }}>
            {reportStats.avgResolutionHours} hrs
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', marginTop: '0.5rem' }}>
            Average time elapsed from UNDER REVIEW state to RESOLVED state.
          </p>
        </Card>

        <Card>
          <h4 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '1rem' }}>Escalation Rate</h4>
          <div style={{ fontSize: '2.5rem', fontWeight: 800, color: 'var(--status-escalated-text)' }}>
            {reportStats.escalationRate}%
          </div>
          <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', marginTop: '0.5rem' }}>
            Complaints requiring Directorate intervention or re-opening.
          </p>
        </Card>
      </div>
    </div>
  );
};

export default Reports;