export const formatDate = (dateString) => {
  if (!dateString) return '-';
  const date = new Date(dateString);
  return new Intl.DateTimeFormat('en-IN', {
    day: '2-digit',
    month: 'short',
    year: 'numeric',
    hour: '2-digit',
    minute: '2-digit'
  }).format(date);
};

export const formatFileSize = (bytes) => {
  if (!bytes) return '0 Bytes';
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};

export const getRoleDisplayName = (role) => {
  const map = {
    student: 'Student',
    class_teacher: 'Class Teacher',
    hod: 'Head of Department (HOD)',
    exam_admin: 'Examination Controller',
    library_admin: 'Chief Librarian',
    warden: 'Chief Hostel Warden',
    transport_supervisor: 'Transport Supervisor',
    hr_finance_admin: 'Finance & Accounts Officer',
    director: 'Director / Dean Academic',
    super_admin: 'Super Administrator'
  };
  return map[role] || role;
};