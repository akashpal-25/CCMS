import React from 'react';
import { CheckCircle2, Clock, AlertCircle } from 'lucide-react';
import { formatDate } from '../../utils/formatters';

const ComplaintTimeline = ({ timeline = [] }) => {
  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem', position: 'relative' }}>
      {timeline.map((item, index) => (
        <div key={item.id || index} style={{ display: 'flex', gap: '1rem', position: 'relative' }}>
          {/* Vertical indicator line */}
          {index !== timeline.length - 1 && (
            <div
              style={{
                position: 'absolute',
                top: '24px',
                left: '11px',
                bottom: '-20px',
                width: '2px',
                backgroundColor: 'var(--color-border)'
              }}
            />
          )}

          {/* Icon bullet */}
          <div
            style={{
              width: '24px',
              height: '24px',
              borderRadius: '50%',
              backgroundColor: index === 0 ? 'var(--color-primary)' : 'var(--color-bg-muted)',
              color: index === 0 ? '#fff' : 'var(--color-text-muted)',
              display: 'flex',
              alignItems: 'center',
              justifyContent: 'center',
              flexShrink: 0,
              zIndex: 1
            }}
          >
            {index === 0 ? <CheckCircle2 size={14} /> : <Clock size={12} />}
          </div>

          {/* Timeline Content */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: '0.2rem', paddingBottom: '0.5rem' }}>
            <div style={{ display: 'flex', alignItems: 'center', gap: '0.5rem' }}>
              <span style={{ fontSize: '0.875rem', fontWeight: 600, color: 'var(--color-text-main)' }}>
                {item.title}
              </span>
              <span style={{ fontSize: '0.75rem', color: 'var(--color-text-light)' }}>
                {formatDate(item.timestamp)}
              </span>
            </div>
            <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)', margin: 0 }}>
              {item.description}
            </p>
            {item.actor && (
              <span style={{ fontSize: '0.7rem', color: 'var(--color-primary)', fontWeight: 500 }}>
                Action by: {item.actor}
              </span>
            )}
          </div>
        </div>
      ))}
    </div>
  );
};

export default ComplaintTimeline;