import React, { useEffect, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, AlertTriangle, Send } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import { complaintService } from '../../services/complaintService';
import { COMPLAINT_STATUS } from '../../utils/constants';
import Card from '../../components/ui/Card';
import Button from '../../components/common/Button';
import StatusBadge from '../../components/ui/StatusBadge';
import SLATimer from '../../components/complaints/SLATimer';
import ComplaintTimeline from '../../components/complaints/ComplaintTimeline';
import Loader from '../../components/common/Loader';
import { formatDate } from '../../utils/formatters';

const AdminComplaintDetails = () => {
  const { complaintId } = useParams();
  const navigate = useNavigate();
  const { user } = useAuthStore();

  const [complaint, setComplaint] = useState(null);
  const [commentText, setCommentText] = useState('');
  const [statusToSet, setStatusToSet] = useState(COMPLAINT_STATUS.IN_PROGRESS);
  const [loading, setLoading] = useState(true);

  const load = async () => {
    if (complaintId) {
      const data = await complaintService.getComplaintById(complaintId);
      setComplaint(data);
      setStatusToSet(data.status);
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, [complaintId]);

  const handleUpdateStatus = async () => {
    await complaintService.updateStatus(complaint.id, statusToSet, commentText, user?.name);
    setCommentText('');
    load();
  };

  const handleEscalate = async () => {
    await complaintService.escalateComplaint(complaint.id, 'Escalated by administrator authority.', user?.name);
    load();
  };

  if (loading || !complaint) return <Loader message="Loading grievance audit file..." />;

  return (
    <div style={{ maxWidth: '1100px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      
      <Button variant="outline" size="sm" icon={ArrowLeft} onClick={() => navigate('/admin/complaints')} style={{ alignSelf: 'flex-start' }}>
        Back to Queue
      </Button>

      {/* Header Info */}
      <Card style={{ padding: '1.5rem', display: 'flex', justifyContent: 'space-between', alignItems: 'center', flexWrap: 'wrap', gap: '1rem' }}>
        <div>
          <div style={{ display: 'flex', alignItems: 'center', gap: '0.75rem' }}>
            <span style={{ fontSize: '1.25rem', fontFamily: 'monospace', fontWeight: 700, color: 'var(--color-primary)' }}>
              {complaint.id}
            </span>
            <StatusBadge status={complaint.status} />
          </div>
          <h2 style={{ fontSize: '1.25rem', fontWeight: 700, marginTop: '0.35rem' }}>{complaint.title}</h2>
          <span style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>
            Student: <strong>{complaint.studentName}</strong> ({complaint.studentId}) • {complaint.department} • Filed: {formatDate(complaint.createdAt)}
          </span>
        </div>
      </Card>

      <SLATimer deadline={complaint.slaDeadline} status={complaint.status} />

      <div style={{ display: 'grid', gridTemplateColumns: '1.3fr 1fr', gap: '1.5rem' }}>
        
        {/* Left: Statement & Admin Action Console */}
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1.25rem' }}>
          <Card>
            <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, marginBottom: '0.5rem' }}>Grievance Description</h4>
            <p style={{ fontSize: '0.875rem', lineHeight: 1.6 }}>{complaint.description}</p>
          </Card>

          {/* Action Console */}
          <Card style={{ border: '2px solid var(--color-primary)', padding: '1.5rem' }}>
            <h4 style={{ fontSize: '1rem', fontWeight: 700, marginBottom: '1rem', color: 'var(--color-primary)' }}>Administrative Action Console</h4>
            
            <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
              <div>
                <label style={{ fontSize: '0.8125rem', fontWeight: 600 }}>Update Lifecycle Status</label>
                <select
                  value={statusToSet}
                  onChange={(e) => setStatusToSet(e.target.value)}
                  style={{ width: '100%', padding: '0.625rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', marginTop: '0.25rem' }}
                >
                  {Object.values(COMPLAINT_STATUS).map((s) => (
                    <option key={s} value={s}>{s}</option>
                  ))}
                </select>
              </div>

              <div>
                <label style={{ fontSize: '0.8125rem', fontWeight: 600 }}>Add Official Remark / Resolution Note</label>
                <textarea
                  rows={3}
                  value={commentText}
                  onChange={(e) => setCommentText(e.target.value)}
                  placeholder="Record action taken, vendor dispatch, or verification result..."
                  style={{ width: '100%', padding: '0.625rem', borderRadius: 'var(--radius-md)', border: '1px solid var(--color-border)', marginTop: '0.25rem', fontFamily: 'inherit' }}
                />
              </div>

              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '0.5rem' }}>
                <Button variant="danger" size="sm" icon={AlertTriangle} onClick={handleEscalate}>
                  Escalate to Director
                </Button>
                <Button variant="primary" icon={CheckCircle} onClick={handleUpdateStatus}>
                  Commit Status Update
                </Button>
              </div>
            </div>
          </Card>
        </div>

        {/* Right: Timeline */}
        <div>
          <Card>
            <h4 style={{ fontSize: '0.9375rem', fontWeight: 600, marginBottom: '1rem' }}>Audit Timeline</h4>
            <ComplaintTimeline timeline={complaint.timeline} />
          </Card>
        </div>

      </div>

    </div>
  );
};

export default AdminComplaintDetails;