import React, { useEffect, useState } from 'react';
import { adminService } from '../../services/adminService';
import Card from '../../components/ui/Card';
import Table from '../../components/ui/Table';
import Button from '../../components/common/Button';
import { getRoleDisplayName } from '../../utils/formatters';

const UserManagement = () => {
  const [users, setUsers] = useState([]);

  useEffect(() => {
    const load = async () => {
      const data = await adminService.getAllUsers();
      setUsers(data);
    };
    load();
  }, []);

  const headers = ['Name', 'College ID / Email', 'Role', 'Department', 'Status', 'Action'];

  return (
    <div style={{ display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>System User Management</h2>
        <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Super Admin control panel for students, faculty mentors, and administrators.</p>
      </div>

      <Card style={{ padding: 0, overflow: 'hidden' }}>
        <Table headers={headers}>
          {users.map((u) => (
            <tr key={u.id} style={{ borderBottom: '1px solid var(--color-border)' }}>
              <td style={{ padding: '1rem', fontWeight: 600 }}>{u.name}</td>
              <td style={{ padding: '1rem', fontSize: '0.8125rem' }}>
                <div>{u.collegeId}</div>
                <div style={{ color: 'var(--color-text-muted)' }}>{u.email}</div>
              </td>
              <td style={{ padding: '1rem', fontSize: '0.8125rem' }}>{getRoleDisplayName(u.role)}</td>
              <td style={{ padding: '1rem', fontSize: '0.8125rem' }}>{u.department}</td>
              <td style={{ padding: '1rem' }}>
                <span style={{ fontSize: '0.75rem', fontWeight: 600, color: 'var(--status-resolved-text)', backgroundColor: 'var(--status-resolved-bg)', padding: '0.2rem 0.5rem', borderRadius: 'var(--radius-full)' }}>
                  ACTIVE
                </span>
              </td>
              <td style={{ padding: '1rem' }}>
                <Button size="sm" variant="outline" onClick={() => alert(`User account settings for ${u.name}`)}>
                  Edit
                </Button>
              </td>
            </tr>
          ))}
        </Table>
      </Card>
    </div>
  );
};

export default UserManagement;