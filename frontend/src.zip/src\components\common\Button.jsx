import React from 'react';

const Button = ({
  children,
  variant = 'primary', // primary | secondary | outline | danger | success
  size = 'md',         // sm | md | lg
  isLoading = false,
  disabled = false,
  type = 'button',
  onClick,
  className = '',
  icon: Icon = null
}) => {
  const baseStyles = {
    display: 'inline-flex',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.5rem',
    fontWeight: '500',
    borderRadius: 'var(--radius-md)',
    border: '1px solid transparent',
    cursor: disabled || isLoading ? 'not-allowed' : 'pointer',
    opacity: disabled || isLoading ? 0.65 : 1,
    transition: 'var(--transition-fast)',
    padding: size === 'sm' ? '0.35rem 0.75rem' : size === 'lg' ? '0.75rem 1.5rem' : '0.5rem 1rem',
    fontSize: size === 'sm' ? '0.8125rem' : size === 'lg' ? '1rem' : '0.875rem'
  };

  const variantStyles = {
    primary: {
      backgroundColor: 'var(--color-primary)',
      color: '#fff'
    },
    secondary: {
      backgroundColor: 'var(--color-bg-muted)',
      color: 'var(--color-text-main)',
      borderColor: 'var(--color-border)'
    },
    outline: {
      backgroundColor: 'transparent',
      borderColor: 'var(--color-border)',
      color: 'var(--color-text-main)'
    },
    danger: {
      backgroundColor: 'var(--status-not-solved-text)',
      color: '#fff'
    },
    success: {
      backgroundColor: 'var(--status-resolved-text)',
      color: '#fff'
    }
  };

  return (
    <button
      type={type}
      disabled={disabled || isLoading}
      onClick={onClick}
      style={{ ...baseStyles, ...variantStyles[variant] }}
      className={className}
    >
      {isLoading ? (
        <span style={{ display: 'inline-block', animation: 'spin 1s linear infinite' }}>⟳</span>
      ) : (
        Icon && <Icon size={size === 'sm' ? 14 : 18} />
      )}
      {children}
    </button>
  );
};

export default Button;