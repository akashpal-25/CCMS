import React from 'react';
import { User, Mail, GraduationCap, Building2, Calendar } from 'lucide-react';
import { useAuthStore } from '../../store/authStore';
import Card from '../../components/ui/Card';

const StudentProfile = () => {
  const { user } = useAuthStore();

  return (
    <div style={{ maxWidth: '700px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>Student Profile</h2>
        <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Official academic enrollment records from university database.</p>
      </div>

      <Card style={{ padding: '2rem' }}>
        <div style={{ display: 'flex', alignItems: 'center', gap: '1.5rem', marginBottom: '2rem', borderBottom: '1px solid var(--color-border)', paddingBottom: '1.5rem' }}>
          <div style={{
            width: '64px',
            height: '64px',
            borderRadius: '50%',
            backgroundColor: 'var(--color-primary)',
            color: '#fff',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            fontSize: '1.5rem',
            fontWeight: 700
          }}>
            {user?.name?.charAt(0)}
          </div>
          <div>
            <h3 style={{ fontSize: '1.25rem', fontWeight: 700 }}>{user?.name}</h3>
            <span style={{ fontSize: '0.875rem', color: 'var(--color-text-muted)' }}>Roll / ID: {user?.collegeId}</span>
          </div>
        </div>

        <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1.25rem' }}>
          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>Email Address</span>
            <p style={{ fontSize: '0.9375rem', fontWeight: 600, marginTop: '0.2rem' }}>{user?.email}</p>
          </div>

          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>Department</span>
            <p style={{ fontSize: '0.9375rem', fontWeight: 600, marginTop: '0.2rem' }}>{user?.department}</p>
          </div>

          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>Program / Course</span>
            <p style={{ fontSize: '0.9375rem', fontWeight: 600, marginTop: '0.2rem' }}>{user?.course}</p>
          </div>

          <div>
            <span style={{ fontSize: '0.75rem', color: 'var(--color-text-muted)', textTransform: 'uppercase' }}>Academic Standing</span>
            <p style={{ fontSize: '0.9375rem', fontWeight: 600, marginTop: '0.2rem' }}>{user?.year} ({user?.semester})</p>
          </div>
        </div>
      </Card>
    </div>
  );
};

export default StudentProfile;