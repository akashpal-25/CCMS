import React from 'react';
import Card from '../../components/ui/Card';
import Input from '../../components/common/Input';
import Button from '../../components/common/Button';
import { useAuthStore } from '../../store/authStore';

const Settings = () => {
  const { user } = useAuthStore();

  return (
    <div style={{ maxWidth: '800px', margin: '0 auto', display: 'flex', flexDirection: 'column', gap: '1.5rem' }}>
      <div>
        <h2 style={{ fontSize: '1.25rem', fontWeight: 700 }}>System Settings</h2>
        <p style={{ fontSize: '0.8125rem', color: 'var(--color-text-muted)' }}>Portal configuration and administrative preferences.</p>
      </div>

      <Card style={{ padding: '1.5rem' }}>
        <h3 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '1rem' }}>User Profile Info</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <Input label="Name" value={user?.name || ''} disabled />
          <Input label="Email" value={user?.email || ''} disabled />
          <Input label="Designation" value={user?.designation || user?.role || ''} disabled />
        </div>
      </Card>

      <Card style={{ padding: '1.5rem' }}>
        <h3 style={{ fontSize: '1rem', fontWeight: 600, marginBottom: '1rem' }}>72-Hour SLA Configuration</h3>
        <div style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
          <Input label="Default Resolution SLA (Hours)" value="72" disabled helperText="Enforced institutional resolution deadline before auto-escalation to Director." />
        </div>
      </Card>
    </div>
  );
};

export default Settings;